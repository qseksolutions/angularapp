import { Component, OnInit } from '@angular/core';
// import * as XLSX from 'ts-xlsx';
import * as Excel from "exceljs/dist/exceljs.min.js";
import * as ExcelProper from "exceljs";
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

declare var $;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [ApiService],
})
export class HomeComponent implements OnInit {

  fileReaded: any;
  arrayBuffer: any;
  file: File;

  constructor(private apiservice: ApiService, private router: Router) { }

  ngOnInit() {
    this.apiservice.getcurrencylist().subscribe(data => {
      console.log(data);
    });
  }
  convertFile(csv: any) {

    /* this.fileReaded = csv.target.files[0];

    let reader: FileReader = new FileReader();
    reader.readAsText(this.fileReaded);

    reader.onload = (e) => {
      let csv = reader.result;
      let allTextLines = csv.split(/\r|\n|\r/);
      let headers = allTextLines[0].split(',');
      let lines = [];
      let r = 0;

      for (let i = 1; i < allTextLines.length; i++) {
        let data = allTextLines[i].split(',');
        if (data.length === headers.length) {
          let tarr = [];
          for (let j = 0; j < headers.length; j++) {
            tarr.push(data[j]);
          }
          lines[i] = tarr;
        }
      }
      lines = $.grep(lines, function (n) { return (n); });
      console.log(lines);
    } */
  }

  incomingfile(event) {
    this.file = event.target.files[0];
    let wb: ExcelProper.Workbook = new Excel.Workbook();
    console.log(wb);
    wb.xlsx.readFile(event.target.files[0]).then(function () {

      var sh = wb.getWorksheet("Sheet1");

      sh.getRow(3).getCell(2).value = 32;
      // wb.xlsx.writeFile("./test.xlsx");
      console.log("Row-3 | Cell-2 - " + sh.getRow(3).getCell(2).value);

      console.log(sh.rowCount);
      //Get all the rows data [1st and 2nd column]
      for (let i = 1; i <= sh.rowCount; i++) {
        console.log(sh.getRow(i).getCell(1).value);
        console.log(sh.getRow(i).getCell(2).value);
      }
    })
  }

  Upload() {
    
    /* let fileReader = new FileReader();
    fileReader.onload = (e) => {
      this.arrayBuffer = fileReader.result;
      var data = new Uint8Array(this.arrayBuffer);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");
      var workbook = XLSX.read(bstr, { type: "binary" });
      var first_sheet_name = workbook.SheetNames[1];
      var worksheet = workbook.Sheets[first_sheet_name];
      console.log(XLSX.utils.sheet_to_json(worksheet, { raw: true }));
      this.apiservice.insertdata(XLSX.utils.sheet_to_json(worksheet, { raw: true })).subscribe(data => {
        console.log(data);
      });
    }
    fileReader.readAsArrayBuffer(this.file); */
  }

}
